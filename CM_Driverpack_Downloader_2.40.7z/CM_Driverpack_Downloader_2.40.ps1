﻿<#  Creator @gwblok - GARYTOWN.COM (original script)
    Used to download Drivers Updates from HP
    This Script was created to build a Drivers Update Package. 
 
 
    REQUIREMENTS:  HP Client Management Script Library
    Download / Installer: https://ftp.hp.com/pub/caps-softpaq/cmit/hp-cmsl.html  
    Docs: https://developers.hp.com/hp-client-management/doc/client-management-script-library
 
    Modes... Report - only compares HP against what is in SCCM (No downloading)
             Download - Downloads DriverPacks and Updates SCCM as needed
   
    Dan Felman/HP Inc: Reformatted script to support Report, Download properly
    Changes:
        - when a CM Package is not created or available in CM, the script will now
            create a Package and show it on the Gui... 
        - removed the need to maintain CM Package IDs... it is all resolved in the code  
        - option Download will now create a CM S/W Package if none exists    
        - Added ability to report on CM Task Sequence Module and Steps
        - Added ability to create NEW steps in TS Module as Product/Model entries are added to script 
        - added ability to select what models to Report or Download during runtime
        - added ability to change OS versions (supported versions listed in ini.ps1 file)
        - some color coding in Data view to show if checking a OS version but CM has a different version in the S/W package
        - GUI Front End
        # DriverPack information publised in PS DataGrid table
        Ver 2.2 - replaced WIndows OS version entry with combobox of allowed versions from PS1 file
            - moved Debug Output checkmark near the output box
            - added OS version to Softpaq version on CM's package Version header (e.g. '1903 - 10.0')
        Ver 2.23
            - added Tooltips to Gui fields
            - modified function Update_SoftpaqFolders to clean up the Temp folder correctly, where there
                were some ACL permissions issues... If script is run with Admin rights, it should be fine
        Ver 2.30
            - More Tooltips for Gui fields
            - renamed table column header: 'Step' to 'TS Step' - seems more descriptive
            - NEW: added ability to move Driver Packages to CM folders based on OS version (e.g. 1809, 1903, etc.)
                included setting checkmark in the Gui, enabled by default
        ver 2.31
            - FIX: Items not checked are cleared at next Report/Download
        ver 2.32
            - Fix: ini file proper update status of Use CM FOlders
        ver 2.33
            - Fix: error creating CM Package if it didn't exist alreay...
                due to incorrect location for 'set-location C:' in function Option_Download
            - Fix: error listing info when Driverpack downloads successfully but CM Package not yet created
        ver 2.35
            - Additional DriverPack download Fixes and cleanup
        ver 2.40
            - added support to allow Package step to be removed if Package points to incorrect OS Version
              this works when doing a Report
            - added check for both required TSs at startup
            - added information on DriverPack package source to list
#>

[CmdletBinding()]
param(
	[Parameter(Mandatory = $false,Position = 1,HelpMessage = "Application")]
	[ValidateNotNullOrEmpty()]
	[ValidateSet("Report","Download")]
	$RunMethod = "Report"
)
$ScriptVersion = "2.40 (3/26/2020)"

$scriptName = $MyInvocation.MyCommand.Name
$ScriptPath = Split-Path $MyInvocation.MyCommand.Path

#Settings for Google - Rest of Info @ Bottom
#$SMTPServer = "smtp.gmail.com"
#$SMTPPort = "587"
#$Username = "username@gmail.com"
#$Password = "password"

#Script Vars
#$EmailArray = @()

<#
    These settings are needed to support this Drivers as Software Packages script
#>

# This Task Sequence will hold ALL Driver Package steps, and is required
$TSDriverModuleName = "Driver Package Module"
$TSDriverPackageModule_Desc = "This task hosts the downloaded package content steps used for driver injection"

# The Driver Injection Module is called by the Deployment Task Sequence and will not be modified once set up
$TSDriverInjectionName = "Driver Injection Module"
$TSDriverInjectionModule_Desc = "This task calls the Driver Package Module to download the driver package to the local disk and then uses DISM to inject drivers"

#--------------------------------------------------------------------------------------
#Reset Vars

$AdminRights = $false
$TSDriverModule = $null                            # This Task Sequence will hold ALL Driver Package steps
$CMConnected = $false

$Debug_Output = $false
$TypeWarn = 2
$TypeError = 3
$TypeDebug = 4
$TypeSuccess = 5
$TypeNoNewline = 10

#--------------------------------------------------------------------------------------
# check for ConfigMan PS module on this server

#$CMInstall = "E:\Program Files\Microsoft Configuration Manager\AdminConsole\bin" # NOW in Gui

if (Test-Path $env:SMS_ADMIN_UI_PATH) {
    $CMInstall = Split-Path $env:SMS_ADMIN_UI_PATH
    Import-Module (Join-Path $(Split-Path $env:SMS_ADMIN_UI_PATH) ConfigurationManager.psd1)
} else {
    Write-Host "Can't find CM Installation on this system"
    exit
}

#--------------------------------------------------------------------------------------
#Script Vars Environment Specific loaded from INI.ps1 file
# source the code in the INI file

$IniFile = "CM_Driverpack_ini.ps1"                     # new version removes need for CM Package ID from product list
$IniFIleFullPath = "$($ScriptPath)\$($IniFile)"

. $IniFIleFullPath

$SiteCode = $CMSiteProvider.Name                     

#=====================================================================================
#region: CMTraceLog Function formats logging in CMTrace style
function CMTraceLog {
	[CmdletBinding()]
	param(
		[Parameter(Mandatory = $false)] $Message,
		[Parameter(Mandatory = $false)] $ErrorMessage,
		[Parameter(Mandatory = $false)] $Component = "HP DriverPack Downloader",
		[Parameter(Mandatory = $false)] [int]$Type,
		[Parameter(Mandatory = $true)] $LogFile
	)
	<#
    Type: 1 = Normal, 2 = Warning (yellow), 3 = Error (red)
    #>
	$Time = Get-Date -Format "HH:mm:ss.ffffff"
	$Date = Get-Date -Format "MM-dd-yyyy"

	if ($ErrorMessage -ne $null) { $Type = $TypeError }
	if ($Component -eq $null) { $Component = " " }
	if ($Type -eq $null) { $Type = 1 }

	$LogMessage = "<![LOG[$Message $ErrorMessage" + "]LOG]!><time=`"$Time`" date=`"$Date`" component=`"$Component`" context=`"`" type=`"$Type`" thread=`"`" file=`"`">"

    #$Type = 4: Debug output ($TypeDebug)
    #$Type = 10: no \newline ($TypeNoNewline)

    if ( ($Type -ne $Script:TypeDebug) -or ( ($Type -eq $Script:TypeDebug) -and $Debug_Output) ) {
        $LogMessage | Out-File -Append -Encoding UTF8 -FilePath $LogFile
        OutToForm $Message $Type
        
    } else {
        $lineNum = ((get-pscallstack)[0].Location -split " line ")[1]    # output: CM_Driverpack_Downloader.ps1: line 557
        #Write-Host "$lineNum $(Get-Date -Format "HH:mm:ss") - $Message"
    }

} # function CMTraceLog

#=====================================================================================

Function OutToForm { 
	[CmdletBinding()]
	param( $pMessage, [int]$pmsgType )

    switch ( $pmsgType )
    {
        1 { # default color is black
          }
        2 { $TextBox.SelectionColor = "Brown"
          }
        3 { $TextBox.SelectionColor = "Red"                   # Error
          }
        4 { $TextBox.SelectionColor = "Orange"                # Debug Output
          }
        5 { $TextBox.SelectionColor = "Green"                 # success details
          }
        10 { # do NOT add \newline to message output
          }

    } # switch ( $pmsgType )

    if ( $pmsgType -eq $Script:TypeDebug ) {
        $pMessage = "<dbg>"+$pMessage
    }

    if ( $pmsgType -eq $TypeNoNewline ) {
        $TextBox.AppendText($pMessage+"")
    } else {
        $TextBox.AppendText($pMessage+"`n")
    }
    $TextBox.Refresh()
    $TextBox.ScrollToCaret()

} # Function OutToForm

#=====================================================================================
<#
    Function Test_CMConnection
        The function will test the CM server connection
        and that the Task Sequences required for use of the Script are available in CM
        - will also test that both download and share paths exist
#>
Function Test_CMConnection {

    $boolConnectionRet = $False

    CMTraceLog -Message "Connecting to CM Server: ""$FileServerName""" -Type $TypeNoNewline -LogFile $LogFile
    
    if (Test-Path $CMInstall) {
        
        try { Test-Connection -ComputerName "$FileServerName" -Quiet

            CMTraceLog -Message " ...Connected" -Type $TypeSuccess -LogFile $LogFile
            $boolConnectionRet = $True
            #$EmailArray += "<font color=Black>Script was run in Mode: $($RunMethod)</font><br>"
            #$EmailArray += "<font color=Black>Connecting to File Share Server: $($FileServerName)</font><br>"

            # -----------------------------------------------------------            
            # Now, let's make sure the CM Drivers Module Task Sequence is in place

            CMTraceLog -Message "Testing for Task Sequence: ""$($TSDriverModuleName)""" -Type $TypeNoNewline -LogFile $LogFile

            Set-Location -Path "$($SiteCode):"
            $Script:TSDriverModule = Get-CMTaskSequence -Name $TSDriverModuleName
            if ($TSDriverModule) {
                CMTraceLog -Message " ...Task Sequence ($($TSDriverModule.PackageID)) Found" -Type $TypeSuccess -LogFile $LogFile
            } else {
                $boolConnectionRet = $False
		        CMTraceLog -Message " ...Task Sequence NOT Found - REQUIRED" -Type $TypeError -LogFile $LogFile
	        } # else
	        Set-Location -Path "C:"
            # -----------------------------------------------------------
        }
        catch {
	        CMTraceLog -Message "Not Connected to File Server, Exiting" -Type $TypeError -LogFile $LogFile
        }
    } else {
        CMTraceLog -Message "CM Installation path NOT FOUND: '$CMInstall'" -Type $TypeError -LogFile $LogFile
    } # else
    
    #================================================================================
    # Let's now also test for the Download and Share paths 
    #
    $DownloadSoftpaqDirToCheck = $DownloadSoftpaqDir.Replace('\'+$OSVER,"")
    CMTraceLog -Message "Testing for Download Path: ""$($DownloadSoftpaqDirToCheck)""" -Type $TypeNoNewline -LogFile $LogFile
    if (Test-Path -Path $DownloadSoftpaqDirToCheck -IsValid) {
        CMTraceLog -Message " ...Path is valid" -Type $TypeSuccess -LogFile $LogFile
    } else {
        CMTraceLog -Message " ...Path is NOT valid" -Type $TypeError -LogFile $LogFile
        $boolConnectionRet = $false
    }
    
    $ExtractPackageShareDirToCheck = $ExtractPackageShareDir.Replace('\HP-'+$OSVER,"")
    CMTraceLog -Message "Testing for Share Path: ""$($ExtractPackageShareDirToCheck)""" -Type $TypeNoNewline -LogFile $LogFile
    if (Test-Path -Path $ExtractPackageShareDirToCheck -IsValid) {
        CMTraceLog -Message " ...Path is valid" -Type $TypeSuccess -LogFile $LogFile
    } else {
        CMTraceLog -Message " ...Path is NOT valid" -Type $TypeError -LogFile $LogFile
        $boolConnectionRet = $false
    }

    #================================================================================
    # Finally, let's check the status of the 2 TS required for everything to work 
    #
    CM_ManageTS $True                             # $true = Report ONLY

    return $boolConnectionRet

} # Function Test_CMConnection

#=====================================================================================
<#
    Function CM_ManageTS
    check on, or create the 2 Task Sequences used by the script packages
    Parameters:
        $pReportOnly - if $true, just show if TSs exist
#>

Function CM_ManageTS { 
[CmdletBinding()]
	param( $pReportOnly )

    Set-Location -Path "$($SiteCode):"

    #######################################################################################################
    # Driver Package Module

    $lTSDriverModule = Get-CMTaskSequence -Name $TSDriverModuleName

    CMTraceLog -Message "Required Task Sequence: $($TSDriverModuleName)" -Type 10 -LogFile $LogFile

    if ( $lTSDriverModule ) {
        CMTraceLog -Message "... Found" -Type $TypeSuccess -LogFile $LogFile
    } else {
        CMTraceLog -Message "... NOT Found" -Type $TypeWarn -LogFile $LogFile
        if ( $pReportOnly -eq $false ) {
            # let's create the Task Sequence we need
            CMTraceLog -Message "... Adding TS to SCCM" -Type $TypeDebug -LogFile $LogFile
            $lTSDriverModule = New-CMTaskSequence -CustomTaskSequence -Name $TSDriverModuleName -Description $TSDriverPackageModule_Desc
            # create the new group
            $PackageGroup = New-CMTaskSequenceGroup -Name "Driver Packages as Software Packages"
            Add-CMTaskSequenceStep -InsertStepStartIndex 0 -TaskSequenceName $lTSDriverModule.Name -Step $PackageGroup
            CMTraceLog -Message "... TS ""$($lTSDriverModule.Name)"" created." -Type 1 -LogFile $LogFile    
        } # if ( $pReportOnly )
    } # else if ( $TSDriverModule )

    #######################################################################################################
    # Driver Injection Module - called by Deployment Task Sequence

    $lTSInjectionModule = Get-CMTaskSequence -Name $TSDriverInjectionName

    CMTraceLog -Message "Required Task Sequence: $($lTSInjectionModule.Name)" -Type 10 -LogFile $LogFile

    if ( $lTSInjectionModule ) {
        CMTraceLog -Message "... Found" -Type $TypeSuccess -LogFile $LogFile
    } else {
        CMTraceLog -Message "... NOT Found" -Type $TypeWarn -LogFile $LogFile

        if ( $pReportOnly -eq $false ) {
            # let's create the Task Sequence ir asked for
            CMTraceLog -Message "... Adding TS to SCCM" -Type $TypeDebug -LogFile $LogFile
            $lTSInjectionModule = New-CMTaskSequence -CustomTaskSequence -Name $TSDriverInjectionName -Description $TSDriverInjectionModule_Desc
            # create the new group
            $InjectionGroup = New-CMTaskSequenceGroup -Name "Driver Management"
            Add-CMTaskSequenceStep -InsertStepStartIndex 0 -TaskSequenceName $lTSInjectionModule.Name -Step $InjectionGroup
        
            # add the Run Task Sequence Module step
            $TSDriverModuleSubStep = New-CMTSStepRunTaskSequence -Name $TSDriverModuleName -RunTaskSequence $TSDriverModule
            Set-CMTaskSequenceGroup -InputObject $lTSInjectionModule -StepName $InjectionGroup.Name -AddStep $TSDriverModuleSubStep -InsertStepStartIndex 0

            # add the Run DISM step w/option to run ONLY if the copy succeeded (e.g. %_SMSTSMDataPath%\Drivers exists)
        
            $DISMCommand = "DISM.exe /Image:%OSDTargetSystemDrive%\ /Add-Driver /Driver:%_SMSTSMDataPath%\Drivers\ /Recurse /logpath:%_SMSTSLogPath%\dism.log"
            $DISMCommand_Desc = "Run DISM to inject all drivers downloaded to the client - Use /Recurse option"

            $lQuery = New-CMTSStepConditionFolder -FolderPath "%_SMSTSMDataPath%\Drivers"
            $IfAny = New-CMTSStepConditionIfStatement -StatementType Any -Condition $lQuery
            $DISMCmdSubStep = New-CMTSStepRunCommandLine -CommandLine $DISMCommand -Name "Install Downloaded Drivers via DISM /Recurse" -Description $DISMCommand_Desc -Condition $IfAny
            Set-CMTaskSequenceGroup -InputObject $lTSInjectionModule -StepName $InjectionGroup.Name -AddStep $DISMCmdSubStep -InsertStepStartIndex 1

            CMTraceLog -Message "... TS ""$($lTSInjectionModule.Name)"" created." -Type 1 -LogFile $LogFile
        } # if ( $pReportOnly -eq $false )
    } # else

	Set-Location -Path "C:"

    if ( $pReportOnly -eq $false ) {
        CMTraceLog -Message "*** Done Managing Driver Module and Injection Task Sequences" -Type 1 -LogFile $LogFile
    } # if ( $pReportOnly -eq $false )

} # Function CM_ManageTS

#=====================================================================================
<#
    Function Check_Softpaq
    This function will check the downloaded Softpaq against the size and MD5 checksums
    Parameters:
        HP DriverPack Softpaq - executable to check
    Returns:
        $true - if softpaq is in good condition
#>
function Check_Softpaq {
[CmdletBinding()]
	param($pHPDriverPackExePath)

    $ltested = $false

    #$lSoftpaqPath = (Get-Item $pHPDriverPackExePath).DirectoryName
    $lSoftpaqPath = Split-Path -path $pHPDriverPackExePath
    $lSoftpaqID = [System.IO.Path]::GetFileNameWithoutExtension($pHPDriverPackExePath)     # get the file name without the .exe extension

    $lSoftpaqMD5 = (Get-SoftpaqMetadata $lSoftpaqID).Softpaq.SoftPaqMD5

    # IF Softpaq exists, let's make sure it is a good download
    if (Test-Path $pHPDriverPackExePath) {
        
        CMTraceLog -Message "... Softpaq '''$($pHPDriverPackExePath)' downloaded, will check it" -Type 1 -LogFile $LogFile
        $lComputedMD5 = (Get-FileHash $pHPDriverPackExePath -Algorithm MD5).Hash           # compute the MD5 frmo the Softpaq
        CMTraceLog -Message "... [Softpaq MD5 hash: $($lSoftpaqMD5); Softpaq computed MD5 hash: $($lComputedMD5)]" -Type 1 -LogFile $LogFile
        if ( $lSoftpaqMD5 -eq $lComputedMD5 ) {
            CMTraceLog -Message "... (softpaq already downloaded) hashes MATCH " -Type 1 -LogFile $LogFile
            $ltested = $true
        } else {
            # let's download it again ONCE and check it again
            Get-Softpaq -number $lSoftpaqID -saveAs $pHPDriverPackExePath -overwrite yes   # -DestinationPath "$($env:temp)\SPExtract\$($HPModel.Model)"
            $lComputedMD5 = (Get-FileHash $pHPDriverPackExePath -Algorithm MD5).Hash           # compute the MD5 frmo the Softpaq
            if ( $lSoftpaqMD5 -eq $lComputedMD5 ) {
                CMTraceLog -Message "... (softpaq re-downloaded) hashes MATCH " -Type 1 -LogFile $LogFile
                $ltested = $true
            }
        } # else if ( $lSoftpaqMD5 -eq $lComputedMD5 )

    } else {
        # Executable does not Exist e.g. it was not yet downloaded
        # let's download it and check it
        CMTraceLog -Message "... Softpaq '''$($pHPDriverPackExePath)' does NOT exist, will attempt to download" -Type 1 -LogFile $LogFile
        #$lExtract = New-Item -ItemType directory "$($lSoftpaqPath)\SwExtract" -force
        Get-Softpaq -number $lSoftpaqID -saveAs $pHPDriverPackExePath -overwrite yes 
        $lComputedMD5 = (Get-FileHash $pHPDriverPackExePath -Algorithm MD5).Hash           # compute the MD5 frmo the Softpaq
        if ( $lSoftpaqMD5 -eq $lComputedMD5 ) {
            CMTraceLog -Message "... (Softpaq downloaded) hashes MATCH" -Type 1 -LogFile $LogFile
            $ltested = $true
        }

    } # else if (Test-Path $lDriverPackFullPathExe)

    return $ltested

} # Check_Softpaq

#=====================================================================================
<#
    Function Update_SoftpaqFolders
    downloads new driver pack softpaq and extracts it for CM use
    returns Path of extracted folder in CM share for use in CM Drive Package
    Parameters:
        HP DriverPack - PS Object
        HP Model Name - Used to manage File System folders for that model to download and extract
#>
function Update_SoftpaqFolders {
	[CmdletBinding()]
	param($pHPDriverPack,[string]$pModelName)

    ######################################################################################
    # ... set up the paths for the DriverPack and the extracted OS versions we are searching for...
    # include OSVER version info in Softpaq and Packages folders

    # (ex: Softpaq source - \\...\share\softpaqs\1909\HP EliteBook x360 1030 G3\9.00)
	$Script:DownloadDriverPackFullPath = "$($DownloadSoftpaqDir)\$($Script:OSVER)\$($pModelName)\$($pHPDriverPack.Version)"

    # (ex: Unpack source - \\...\share\packages\HP-1909\HP EliteBook x360 1030 G3)
    # this is the folder in the share that SCCM will draw from
	$script:ExtractPackageShareDirCurrent = "$($ExtractPackageShareDir)$($Script:OSVER)\$($pModelName)"
   
    # name of full path to driverpack, including SP .exe
    $lDriverPackFullPathExe = $DownloadDriverPackFullPath + "\$($pHPDriverPack.id).exe"

    ######################################################################################
    # now, check for the existance of a DriverPack for this model and O/S version
    # if it exists... warn for now... will check versions next with XML config file
    # if it doesn't exist, download it
	
    if (Test-Path $DownloadDriverPackFullPath) {                   # e.g. does the driverpack folder exist?
        CMTraceLog -Message "... Softpaq path '$($DownloadDriverPackFullPath)' exists." -Type $TypeDebug -LogFile $LogFile
	} else {
		CMTraceLog -Message "... Softpaq path '$($DownloadDriverPackFullPath)' does NOT exist. We'll create it" -Type $TypeWarn -LogFile $LogFile
    } # if (Test-Path $DownloadDriverPackFullPath) 

    $Downloaded = Check_Softpaq $lDriverPackFullPathExe

    #Unblock-File -Path $lDriverPackFullPathExe    # Allow open files that were downloaded from the Internet.

    ######################################################################################
    # at this point, we have a DriverPack softpaq downloaded
    # see if the extracted driverpack contents are alreay in place
    # e.g.driverpack extracted already and see if they are current by checking the version

    [bool]$CMPackageNeedsUpdate = $false

	if (Test-Path $Script:ExtractPackageShareDirCurrent) {

        <#
            let's work on the unpacking, if needed to use with a CM Software Package
            ALso, make sure the unpacked driver pack folder is current - use version info from XML file
            e.g. compare XML version info between downloaded DriverPack Softpaq and the extracted/already in place DriverPack

            ----------- HP DriverPack Manifest XML file sample / a PS Package contents ------------------
            <Objs Version="1.1.0.1" xmlns="http://schemas.microsoft.com/powershell/2004/04">
                <Obj RefId="0">
                    <TN RefId="0">
                        <T>Selected.System.Management.Automation.PSCustomObject</T>
                        <T>System.Management.Automation.PSCustomObject</T>
                        <T>System.Object</T>
                    </TN>
                    <MS>
                        <S N="Id">sp99708</S>
                        <S N="Name">HP Elite/ZBook 8x0 G5 Windows 10 x64 Driver Pack</S>
                        <S N="Category">Manageability - Driver Pack</S>
                        <S N="Version">10.0</S>
                        <S N="Vendor">HP</S>
                        <S N="ReleaseType">Routine</S>
                        <S N="SSM">false</S>
                        <S N="DPB">false</S>
                        <S N="Url">ftp.hp.com/pub/softpaq/sp99501-100000/sp99708.exe</S>
                        <S N="ReleaseNotes">ftp.hp.com/pub/softpaq/sp99501-100000/sp99708.html</S>
                        <S N="Metadata">ftp.hp.com/pub/softpaq/sp99501-100000/sp99708.cva</S>
                        <S N="MD5">0688611b9337d4e28685715de5b71aa9</S>
                        <S N="Size">848385496</S>
                        <S N="ReleaseDate">2019-11-22</S>
                    </MS>
                </Obj>
            </Objs>
        #>
		######################################################################
        # let's see if a valid driverpack XML file exists and it is up to date
        ######################################################################
        $PackageXMLfile = "$($Script:ExtractPackageShareDirCurrent)\DriverPackInfo.XML"
	    CMTraceLog -Message "... checking for CM Packge share xml file: '$($PackageXMLfile)'" -Type 1 -LogFile $LogFile

		# get the size of files in extracted folder - in MBs
        # we will check later for AT LEAST 500MB
        $lExtractedFolderSize = (Get-ChildItem $ExtractPackageShareDirCurrent -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum/ "1MB"

        if (Test-Path $PackageXMLfile) {

            # Let's look at the contents of the XML file
			$xmlFile = New-Object -TypeName XML
			$xmlFile.Load($PackageXMLfile)
			$xmlPackageCurrVersion = ($xmlFile.Objs.obj.MS.S | Where-Object { $_.N -eq 'Version' })."#text"
            
            # check that the XML shows the latest version AND that there are at least 500MB worth of files 

			#if ( ($xmlPackageCurrVersion -match $pHPDriverPack.Version) -and ($lExtractedFolderSize -gt 500) ) {
            if ( ($xmlPackageCurrVersion -match $pHPDriverPack.Version) -and ($lExtractedFolderSize -gt 500) ) {
				CMTraceLog -Message "... CM package folder is up to date - (XML file versions match: $($xmlPackageCurrVersion))" -Type 1 -LogFile $LogFile
			} else {
				CMTraceLog -Message "... CM package folder is NOT up to date - (XML file versions do NOT match: [$($xmlPackageCurrVersion)] vs HP: [$($pHPDriverPack.Version)] )" -Type $TypeError -LogFile $LogFile
				$CMPackageNeedsUpdate = $true
			} # else

		} else { # if (Test-Path $PackageXMLfile)
			$CMPackageNeedsUpdate = $true                # XML file does not exist (e.g. drivepack needed)
		} # else if (Test-Path $PackageXMLfile)

	} else {

		CMTraceLog -Message "... CM Package folder does not exist, will create it" -Type $TypeWarn -LogFile $LogFile
		New-Item $script:ExtractPackageShareDirCurrent -ItemType Directory -Force
		CMTraceLog -Message "... CM Package folder created" -Type 1 -LogFile $LogFile
		$CMPackageNeedsUpdate = $true

	} # else if (Test-Path $Script:ExtractPackageShareDirCurrent) 

    ########################################################################
    # DriverPack is available... let's see if we need to update the share
    ########################################################################

    if ( $CMPackageNeedsUpdate ) {
        
        #------------------------------------------------------------------------------
        # Let's make sure the root Temp folder to work on is in place, if not create it
        # Unpack to a TEMP folder, then copy to Packages share

        $TempDir = "$($env:TMP)\SPExtract"
        if ( !(Test-Path $TempDir) ) {
            New-Item $TempDir -ItemType Directory -Force 
        } 
        $TempDir = (Get-Item -Literalpath ("$($env:TMP)\SPExtract")).fullname                # expand to avoid path truncation

        # now, let's remove any folders in our Temp and proper share folders
        CMTraceLog -Message "... Removing Temp folders: $($TempDir)\*" -Type 1 -LogFile $LogFile  

        Start-Process powershell.exe -verb "runAs" -ArgumentList "-Command &{Remove-Item $TempDir\* -Recurse -Force}" -windowstyle "Minimized" -Wait

        $ModelTempDir = "$($TempDir)\$($pModelName)"                                         # add Folder name of product to TEMP folder  
        
        CMTraceLog -Message "... Recreating $($ModelTempDir)" -Type 1 -LogFile $LogFile
        New-Item $ModelTempDir -ItemType Directory -Force 

		CMTraceLog -Message "... Removing Model share path:$($Script:ExtractPackageShareDirCurrent)" -Type 1 -LogFile $LogFile
		Remove-Item -Path $Script:ExtractPackageShareDirCurrent -Recurse -Force -ErrorAction SilentlyContinue
        
        #------------------------------------------------------------------------------
		# now, populate the Temp folder... extract contents of DriverPack Softpaq... 

        CMTraceLog -Message "... Unpacking $($lDriverPackFullPathExe) to $($ModelTempDir)" -Type 1 -LogFile $LogFile
        Start-Process -Verb RunAs $lDriverPackFullPathExe -ArgumentList "-e -s -f""$($ModelTempDir)""" -Wait

        # find the created subfolder
        $SubDir = Get-ChildItem -Path $ModelTempDir -Attributes "Directory" | Sort-Object LastAccessTime -Descending | Select-Object -First 1                                         
        $newCopyPath = "$($ModelTempDir)\$($SubDir)"                                        # (e.g. full path ...\EB_X360_1030_G3)
        
        #------------------------------------------------------------------------------
		# copy contents of subfolder to Packages share for this model and OS 
        # (example unpacked full path ...\EB_X360_1030_G3\wt64_1903)

        # ... TBD ...NEXT: should check for OS folder that matches OSVER we are searching for... TBD ...
        # (e.g. wt64_1809, or wt64_1903, etc. - there may be one or multiple folders potentially)

        $CopyWinFolder = Get-ChildItem -Path "$newCopyPath" -Attributes "Directory" | Sort-Object LastAccessTime -Descending | Select-Object -First 1       
        $CopyFromDir = "$($newCopyPath)\$($CopyWinFolder)"                                  

        #------------------------------------------------------------------------------
        # Next get the unpacked drivers to the SCCM share corresponding to the Model and OS version
		CMTraceLog -Message "... Copying extracted contents to $($Script:ExtractPackageShareDirCurrent)" -Type 1 -LogFile $LogFile
        Copy-Item -path $CopyFromDir -Destination $Script:ExtractPackageShareDirCurrent -Force -Recurse

        # create an XML file for the DriverPack on the share directory
        CMTraceLog -Message "Creating  DriverPack XML file" -Type 1 -LogFile $LogFile
		Export-Clixml -InputObject $pHPDriverPack -Path "$($Script:ExtractPackageShareDirCurrent)\DriverPackInfo.XML"

		#------------------------------------------------------------------------------
        # clean up Temp folder used - fails without SysAdmin privileges !!!
		if (Test-Path $TempDir) {
			CMTraceLog -Message "... Removing Temp folder $($TempDir)" -Type 1 -LogFile $LogFile
		    Start-Process powershell.exe -verb "runAs" -ArgumentList "-Command &{Remove-Item $TempDir\* -Recurse -Force}" -windowstyle "Minimized"
		} # if (Test-Path $TempDir)

    } # if ($CMPackageNeedsUpdate) 

} # function Update_SoftpaqFolders

#=====================================================================================
<#
    function Set_HPDriverPackage
        updates a CM Driver Package and updates CM's Distribution Points

    REQUIREMENTS:
        Driver Package
        DriverPack Name/ID (e.g. sp99111)
        DriverPack Version #
        DriverPack Path on CM Share
    RETURNS:
        updated CM Software Package
#>
function Set_HPDriverPackage {
	[CmdletBinding()]
	param( $psPkg, $psSoftpaqID, $psPkgVersion, $psPath )
    
    CMTraceLog -Message "[Set_HPDriverPackage()] enter" -Type $TypeDebug -LogFile $LogFile        # Debug_Output=$true
    CMTraceLog -Message "..> psPkgName=$($psPkg.name), psPkgID=$($psSoftpaqID), psPkgVersion=$($psPkgVersion), psPath=$($psPath) <<<" -Type $TypeDebug -LogFile $LogFile        # Debug_Output=$true

    Set-Location -Path "$($SiteCode):"

	Set-CMPackage -Name $psPkg.Name -Language $psSoftpaqID
	Set-CMPackage -Name $psPkg.Name -Version "$($OSVER) - $($psPkgVersion)"
	Set-CMPackage -Name $psPkg.Name -Path $psPath

    $psPkg = Get-CMPackage -Name $lEntryModel -Fast                               # make suer we are woring with updated package

    Move_CMPackage $psPkg $OSVER

    Set-Location -Path "$($SiteCode):"
    update-CMDistributionPoint -PackageId $psPkg.PackageID
	Set-Location -Path "C:"

    CMTraceLog -Message "[Set_HPDriverPackage()] exit" -Type $TypeDebug -LogFile $LogFile        # Debug_Output=$true

    Return $psPkg

} # function Set_HPDriverPackage

#=====================================================================================
<#
    Function Update_TSPackageStep
    expects parameter "Driver Package Module TS", "PackageId" , "Package Name"
    Returns String: - if Step found and Associated Package was correct
                    - if Step found but Package ID was incorrect and was corrected
                    - if Step was NOT found and Package Step was added to the Package Module TS
#>
function Update_TSPackageStep {
	[CmdletBinding()]
	param($pTSDriverPackageModule,$pTSDriverPackage,$pProductCode, $pReportOnly)

    CMTraceLog -Message "[Update_TSPackageStep()] enter" -Type $TypeDebug -LogFile $LogFile        # Debug_Output=$true
    CMTraceLog -Message "..> pProductCode=$($pProductCode); pReportOnly=$($pReportOnly) <<<" -Type $TypeDebug -LogFile $LogFile        # Debug_Output=$true

	$lSTEPFoundAndUpToDate = "Download Package STEP was Found in TS:""$($TSDriverModule.Name)"" and Matches CM Package"
	$lSTEPFoundButUpdated = "Download Package STEP was Found, but was Updated"
	$lSTEPNotFoundCreated = "Download Package STEP was Not Found. It was Created"
	$lSTEPFoundButNeedsUpdated = "Download Package STEP was Found, but Package ID is incorrect and Needs Updated"
	$lSTEPNotFound = "Download Package STEP was NOT Found"

	$lStepReturn = $lSTEPFoundAndUpToDate # Assume Package STEP is OK
    [bool]$lStepFound = $false
	$lTSStep = $null

	Set-Location -Path "$($SiteCode):"

	if ($pTSDriverPackageModule -ne $null) {

		# Find all steps already in the Module
		$TSDriverModuleSteps = ($pTSDriverPackageModule | CMTaskSequenceStep)

		# See if the PackageId is already in the Module TS
		$lPosition = 0
		foreach ($TSDriverStep in $TSDriverModuleSteps) {
			if (($TSDriverStep.DownloadPackages -eq $pTSDriverPackage.PackageID) -or ($TSDriverStep.PackageInfo.Name -eq $pTSDriverPackage.Name)) {
				$lPosition += 1
				$lTSStep = $TSDriverStep
                $lStepFound = $true
				continue
			} # if ()
		} # foreach ()

		<#
            If Download Package Step is in the Module, make sure it referrences the correct Package ID
            If Package Step is NOT found, then add it
        #>

		# but, first... Build out the -Condition with the appropriate WMI Query - JUST IN CASE We Need to Add or Mod the Step
		$sWMIQuery = "select * from win32_baseboard where product = ""$($pProductCode)"" "
		$lQuery = New-CMTSStepConditionQueryWmi -Query $sWMIQuery
		$IfAny = New-CMTSStepConditionIfStatement -StatementType Any -Condition $lQuery

		if ( $lStepFound ) {

			# $TSDriverStep was found

			if ($lTSStep.DownloadPackages -ne $pTSDriverPackage.PackageID) {

				if ($pReportOnly) {

					$lStepReturn = $lSTEPFoundButNeedsUpdated

				} else {

					# need to update the Package info in the Step
					# ... Since we can't just update the PackageID in the STEP, Recreate it w/the correct PackageID

					Remove-CMTaskSequenceStep -InputObject $pTSDriverPackageModule -StepName $pTSDriverPackage.Name -Force

					# Create the CM TS Download Software Pckage Step
					$lTSDriverPackageStep = New-CMTaskSequenceStepDownloadPackageContent -AddPackage $pTSDriverPackage `
                        -Name "$($pTSDriverPackage.Name)" `
                        -LocationOption CustomPath `
                        -Path "%_SMSTSMDataPath%\Drivers" `
                        -Description "New Download Drivers TS step created with PowerShell" `
                        -Condition $IfAny
					# ... and add it to the correct TS Module
					$lAddedPackageStep = Set-CMTaskSequenceGroup -InputObject $pTSDriverPackageModule -AddStep $lTSDriverPackageStep -InsertStepStartIndex $lPosition
					update-CMDistributionPoint -PackageId $pTSDriverPackage.PackageID
					$lStepReturn = $lSTEPFoundButUpdated

				} # else

			} # if ( $TSDriverStep.DownloadPackages -ne $pTSDriverPackage.PackageId )

		} else {     # step in Task Sequence NOT Found

			if ($pReportOnly) {
				$lStepReturn = $lSTEPNotFound
                $lStepFound = $false
			} else {

				# Create the CM TS Step   
				$lTSDriverPackageStep = New-CMTaskSequenceStepDownloadPackageContent -AddPackage $pTSDriverPackage `
                    -Name "$($pTSDriverPackage.Name)" `
                    -LocationOption CustomPath `
                    -Path "%_SMSTSMDataPath%\Drivers" `
                    -Description "New Download Drivers TS step created with PowerShell" `
                    -Condition $IfAny
				# add it to the correct TS Module
				$lAddedPackageStep = Set-CMTaskSequenceGroup -InputObject $pTSDriverPackageModule -AddStep $lTSDriverPackageStep -InsertStepStartIndex $lPosition

				update-CMDistributionPoint -PackageId $pTSDriverPackage.PackageID

				$lStepReturn = $lSTEPNotFoundCreated
                $lStepFound = $true

			} # if ( $pReportOnly )

		} # else

	} # ( $pTSDriverPackageModule -ne $null )

	Set-Location -Path "C:"

    #CMTraceLog -Message "... $($lStepReturn): ""$($pTSDriverPackage.Name)""\$($pTSDriverPackage.PackageID)->$($pTSDriverPackage.version)" -Type 1 -LogFile $LogFile

    CMTraceLog -Message "[Update_TSPackageStep()] exit" -Type $TypeDebug -LogFile $LogFile        # Debug_Output=$true

	return $lStepFound

} # Update_TSPackageStep

#=====================================================================================
<#
    Function Remove_TSPackageStep
    expects parameter "Driver Package Module TS", "PackageId" , "Package Name"
    Returns String: - if Step found and Associated Package was correct
                    - if Step found but Package ID was incorrect and was corrected
                    - if Step was NOT found and Package Step was added to the Package Module TS
#>
function Remove_TSPackageStep {
	[CmdletBinding()]
	param($pTSDriverPackageId)

    CMTraceLog -Message "Remove_TSPackageStep enter" -Type $TypeDebug -LogFile $LogFile 
    
    Set-Location -Path "$($SiteCode):"
    $lTSDriverModule = Get-CMTaskSequence -Name $TSDriverModuleName

    if ($lTSDriverModule -ne $null) {

        # Find all steps available in the Task Sequence
		$TSDriverModuleSteps = ($lTSDriverModule | CMTaskSequenceStep)

        # See if the PackageId is already in the Module TS
		foreach ($TSDriverStep in $TSDriverModuleSteps) {
			if ($TSDriverStep.PackageInfo.PackageId -eq $pTSDriverPackageID) {
                $lTSDriverModule | Remove-CMTaskSequenceStep -StepName $TSDriverStep.Name -Force
                CMTraceLog -Message "... Package Step removed from Task Sequence [$($TSDriverStep.Name)]" -Type $TypeDebug -LogFile $LogFile
			} # if ()
		} # foreach ()
 
    } # if ($lTSDriverModule -ne $null)
    Set-Location -Path "C:"

    CMTraceLog -Message "Remove_TSPackageStep exit" -Type $TypeDebug -LogFile $LogFile
    
} # function Remove_TSPackageStep

#=====================================================================================
<#
    Function ListView_FillInItem
        reports items/row on the Model List, like
            Softpaq Name/ID - column 4
            Softpaq Version - column 5
        Parameters
            $pModelsList - list of entries to look at
            $pRow - which row from the list to work on
            $pHPDriverpack - the HP DriverPack
            $pTSStepFound - tells if TS step exists for this package
#>
Function ListView_FillInItem {
    [CmdletBinding()]
	param($pModelsList, $pRow, $pHPDriverpack, $pTSStepFound)

    CMTraceLog -Message "ListView_FillInItem enter" -Type $Script:TypeDebug -LogFile $LogFile 

    # get the model we are looking for
    $lEntryModel = $pModelsList[2,$pRow].Value

    # items are rows, subitems are columns
    # Write-Host -ForegroundColor Yellow $pRow $pModelsList.items[$pRow].subitems[2]

    ListView_ClearRow $pModelsList $pRow                                                          # clear all columns After Model Name

    if ( $pHPDriverpack -ne $null ) {

        # ... find the CM Package to report on
        Set-Location -Path "$($SiteCode):"
        $lCMDriverPackage = Get-CMPackage -Name $lEntryModel -Fast
        Set-Location -Path "C:"

        # --------------------------------------------------------------------------------------------
        # Available HP Driverpack Id and version
        $pModelsList[3,$pRow].Value = ($pHPDriverpack.Id+' - '+$pHPDriverpack.Version)            # Softpaq#

        if ($lCMDriverPackage -ne $null) {

            # --------------------------------------------------------------------------------------------
            # the CM Package source OS version it points to
            $OSVersionStart = $lCMDriverPackage.PkgSourcePath.IndexOf("HP-")                      #     find the package source path's "HP-1909" string location
            $lOSVersion = $lCMDriverPackage.PkgSourcePath.Substring(($OSVersionStart+3),4)         #     Get the Windows Version (e.g. 1903, 1909, etc)
              
            $lPkgVersion = $lCMDriverPackage.Version.split(" ")[-1]#"one - three".split(" ")[-1]  # Get the Softpaq Version in the CM Package (e.g. from '1903 - 8.0' pick off 8.0
            $pModelsList[4,$pRow].Value = $lPkgVersion                                            #$lCMDriverPackage.Version                                   # Softpaq Version 
            if ( $pHPDriverpack.Version -ne $lPkgVersion ) {
                $pModelsList[4,$pRow].Style.ForeColor = "Red"
            } else {
                $pModelsList[4,$pRow].Style.ForeColor = "Black"
            } # if 
            # --------------------------------------------------------------------------------------------
            # OS Version of package
            $pModelsList[5,$pRow].Value = $lOSVersion                                               # OS Version    
            if ( $lOSVersion -ne $OSVER ) {
                $pModelsList[5,$pRow].Style.ForeColor = "Brown"
            } else {
                $pModelsList[5,$pRow].Style.ForeColor = "Black"
            } # if else
                
            $pModelsList[6,$pRow].Value = $lCMDriverPackage.PackageId                              # Actual CM Package ID
        
            # --------------------------------------------------------------------------------------------
            # Path to Package Source

            $pModelsList[7,$pRow].Value = $lCMDriverPackage.PkgSourcePath

            # --------------------------------------------------------------------------------------------
            # Ts Step check - remove if setting is SET and package points to non-selected OS version

            if ( $pTSStepFound ) {
                if ( ( $lOSVersion -ne $OSVER ) -and $RemoveStepsFromTS ) {
                    CMTraceLog -Message "... Removing Package Step - Package source points to OS Version $($lOSVersion)" -Type $TypeError -LogFile $LogFile
                    Remove_TSPackageStep $lCMDriverPackage.PackageId
                } else {
                    $pModelsList[8,$pRow].Value = 'v'                                              # Package Step exists in TS?
                }
            } # if ( $pTSStepFound )

        } # else if ($lCMDriverPackage -eq $null)
    } # else
    $pModelsList.refresh
    CMTraceLog -Message "ListView_FillInItem exit: Pkg Softpaq Ver: $($lCMDriverPackage.Version); Pkg OS Version $($lOSVersion)" -Type $TypeDebug -LogFile $LogFile 

} # Function ListView_FillInItem

#=====================================================================================
<#
#>
Function ListView_ClearRow {
    [CmdletBinding()]
	param($pModelsList, $pRow)

    CMTraceLog -Message "ListView_ClearRow enter" -Type $Script:TypeDebug -LogFile $LogFile 

    $pModelsList[3,$pRow].value = $null                                    # Available from HP
    $pModelsList[4,$pRow].value = $null                                    # CM Version
    $pModelsList[5,$pRow].value = $null                                    # CM OS
    $pModelsList[6,$pRow].value = $null                                    # CM Package
    $pModelsList[7,$pRow].value = $null                                    # Pkg Source
    $pModelsList[8,$pRow].value = $null                                    # TS Step
    $pModelsList.refresh

    CMTraceLog -Message "ListView_ClearRow exit" -Type $Script:TypeDebug -LogFile $LogFile 

} # Function ListView_ClearAllItems 


#=====================================================================================
<#
#>
Function Option_Report {
    [CmdletBinding()]
	param( $pModelsList, $pCheckedItemsList)

    CMTraceLog -Message "Reporting" -Type 1 -LogFile $LogFile

    CMTraceLog -Message "OS Version to check for: $($Script:OSVER)" -Type $Script:TypeDebug -LogFile $LogFile 

    for ( $i = 0; $i -lt $pModelsList.RowCount; $i++ ) {
        if ( $i -in $pCheckedItemsList ) {
            
            # SubItems[0] is the checkmark column
            $lEntryProdCode = $pModelsList[1,$i].Value
            $lEntryModel = $pModelsList[2,$i].Value

            #write-host "$($lEntryProdCode) - $($lEntryModel)"

            # additional debug output, if enabled
            CMTraceLog -Message "Checking: table row:$($i), $($lEntryModel)/$($lEntryProdCode), OS=$($OSVER)" -Type 1 -LogFile $LogFile
        
            $Script:ExtractPackageShareDirCurrent = $null

	        # let's query for HP Driver Pack softpaqs with the HP CMSL
	        CMTraceLog -Message "Obtaining DriverPack Softpaq info" -Type $Script:TypeDebug -LogFile $LogFile
            $SoftPaq = Get-SoftpaqList -platform $lEntryProdCode -os $OS -osver $Script:OSVER
	        $HPDriverPack = $SoftPaq | Where-Object { $_.category -eq 'Manageability - Driver Pack' }
	        $HPDriverPack = $HPDriverPack | Where-Object { $_.Name -notmatch "Windows PE" }
	        $HPDriverPack = $HPDriverPack | Where-Object { $_.Name -notmatch "WinPE" }

	        if ($HPDriverPack) {

                $lMsg = "... HP Driver Pack Available for '$($lEntryModel)/$($lEntryProdCode)' [$($HPDriverPack.ID)/$($HPDriverPack.Version)/$($HPDriverPack.ReleaseDate) - size=$($HPDriverPack.Size)]"
                CMTraceLog -Message $lMsg -Type 1 -LogFile $LogFile

                # Get Current Driver CMPackage Version from CM for this Model - in case it exists already

		        CMTraceLog -Message "Looking for CM Driver Package" -Type $TypeDebug -LogFile $LogFile
                Set-Location -Path "$($SiteCode):"
                $CMDriverPackage = Get-CMPackage -Name $lEntryModel -Fast
                Set-Location -Path "C:"

                # ------------------------------------------------------------------------
                # Check to see if:
                #    - there is a newer version at HP
                #    - (if versions match) the PackageID in CM matches the PackageID in the script
                if ($CMDriverPackage) {

                    # see if the OS Versions of the CM Package match the version we are seeking now
                    $lOSVerMatch = [string]$CMDriverPackage.PkgSourcePath -match $($Script:OSVER)

                    if ( $lOSVerMatch ) {
                        if ( $CMDriverPackage.version -match [String]$HPDriverPack.Version ) {
                            CMTraceLog -Message "... CM Driver Pack version [$($CMDriverPackage.version)] is current" -Type 1 -LogFile $LogFile
                        } else {
                            CMTraceLog -Message "... CM Driver Pack version [$($CMDriverPackage.version)] needs updated to HP Version [$($HPDriverPack.Version)]" -Type $TypeWarn -LogFile $LogFile
                        }
                    } else {
                        # The Version that the CM Package does NOT match the OS Version we are aspiring to
                        CMTraceLog -Message "... CM Package OS version [$($Script:OSVER)] does not match package - $($CMDriverPackage.PkgSourcePath)" -Type $TypeWarn -LogFile $LogFile
                    }
                    # ------------------------------------------------------------------------
                    # Is the source pointed to by the Package exist, and has data (drivers) in it?
                    if ( -not (test-path $CMDriverPackage.PkgSourcePath) ) {
                        CMTraceLog -Message "... CM Package Drivers source missing [$($CMDriverPackage.PkgSourcePath)]" -Type $TypeWarn -LogFile $LogFile
                    } else {
                    }

		        } else {
			            CMTraceLog -Message "... CM Driver Package NOT Found - HP version $($HPDriverPack.Version) available" -Type $TypeError -LogFile $LogFile
                } # else if ( $CMDriverPackage )

                ################################################################################################
		        # Find out if the Driver Package step is in the TS
                # $TSDriverModule is the Tak Sequence containing all Dowlnoad DriverPack Package steps

                #CMTraceLog -Message "Checking Package Step in Task Sequence" -Type $TypeDebug -LogFile $LogFile
                $CMPackageStepFound = Update_TSPackageStep $TSDriverModule $CMDriverPackage $lEntryProdCode $true    # arg: $true = report only, don't update
                CMTraceLog -Message "... $($CMPackageStepFound): ""$($CMDriverPackage.Name)""->$($CMDriverPackage.PackageID)" -Type $TypeDebug -LogFile $LogFile  

		        ################################################################################################

            } else {
                $CMDriverPackage = $null
                $CMPackageStepFound = $false
		        #$EmailArray += "<font color=#8B0000>No Driver Pack Available for<b> $($HPModel.Model) </b>Product Code $($HPModel.ProdCode) via Internet </font><br>"
		        CMTraceLog -Message "... No HP Driver Pack Available for '$($lEntryModel)/$($lEntryProdCode)'" -Type 1 -LogFile $LogFile

	        } # else { # if ($HPDriverPack)
            <#
                ListView_FillInItem parameters:
                    $pModelsList - list of entries to look at
                    $pRow - which row from the list to work on
                    $pHPDriverpack - the HP DriverPack
                    $pTSStepFound - tells if TS step exists for this package
            #>
            ListView_FillInItem $pModelsList $i $HPDriverPack $CMPackageStepFound
        } else {
            # item is NOT checked, so clear the fields in the list
            ListView_ClearRow $pModelsList $i
        } # else if ( $i -in $pCheckedItemsList )
    } # for

    CMTraceLog -Message "*** Done Reporting ***" -Type 1 -LogFile $LogFile

} # Function Option_Report


#=====================================================================================
<#
    Function Option_Download
        This function will find out if a nee DriverPack is available for every product in the checkmarked list
        if available, it will download, unpack and populate the Software Package source
            then, will create or update the CM Software Package associated for the Hp Mode
            it will also create or update the Package entry (step) in the Driver Package Module Task Sequence 
    expects parameter 
        - Gui Model list table
        - list of checked entries from the table checkmarks
        - boolean downloadAndUpdate - for future use
#>
Function Option_Download {
    [CmdletBinding()]
	param( $pModelsList, $pCheckedItemsList )
    
    CMTraceLog -Message "Downloading and Updating CM" -Type 1 -LogFile $LogFile

    CMTraceLog -Message "Checking for OS version: $($OSVER)" -Type $TypeDebug -LogFile $LogFile 

    for ( $i = 0; $i -lt $pModelsList.RowCount; $i++ ) {

        if ( $i -in $pCheckedItemsList ) {
            # SubItems[0] is the checkmark column
            $lEntryProdCode = $pModelsList[1,$i].Value
            $lEntryModel = $pModelsList[2,$i].Value

            CMTraceLog -Message "Checking: table row:$($i); Model=$($lEntryModel)/$($lEntryProdCode); OS=$($OSVER)" -Type 1 -LogFile $LogFile 
        
            $Script:ExtractPackageShareDirCurrent = $null                                 # This is set in Update_SoftpaqFolders
            # let's query for HP Driver Pack softpaqs with the HP CMSL
            $SoftPaq = Get-SoftpaqList -platform $lEntryProdCode -os $OS -osver $Script:OSVER
	        $HPDriverPack = $SoftPaq | Where-Object { $_.category -eq 'Manageability - Driver Pack' }
	        $HPDriverPack = $HPDriverPack | Where-Object { $_.Name -notmatch "Windows PE" }
	        $HPDriverPack = $HPDriverPack | Where-Object { $_.Name -notmatch "WinPE" }
	    
            if ( $HPDriverPack ) {

                $lMsg = "... HP Driver Pack Available for '$($lEntryModel)/$($lEntryProdCode)' [$($HPDriverPack.ID)/$($HPDriverPack.Version)/$($HPDriverPack.ReleaseDate) - size=$($HPDriverPack.Size)]"
                CMTraceLog -Message $lMsg -Type 1 -LogFile $LogFile

			    CMTraceLog -Message "... Updating Softpaq folder" -Type $TypeDebug -LogFile $LogFile
                Update_SoftpaqFolders $HPDriverPack $lEntryModel  

                CMTraceLog -Message "... Looking for CM Driver Package for $($lEntryModel)" -Type $TypeDebug -LogFile $LogFile
                Set-Location -Path "$($SiteCode):"
                $CMDriverPackage = Get-CMPackage -Name $lEntryModel -Fast

                if ( $CMDriverPackage -eq $null ) {

                    CMTraceLog -Message "... CM Package missing... Creating New" -Type 1 -LogFile $LogFile
                    $CMDriverPackage = New-CMPackage -Name $lEntryModel -Manufacturer "HP"                

                } else {
                    CMTraceLog -Message "... found lEntryModel=$($lEntryModel) ; w/lCMDriverPackage.PackageID=$($CMDriverPackage.PackageID)" -Type $TypeDebug -LogFile $LogFile
                    # see if the OS Versions of the CM Package match the version we are looking for now

                    if ( !( [string]$CMDriverPackage.PkgSourcePath -match $($OSVER) ) ) {
                        CMTraceLog -Message "... Package OS version does not match current selection" -Type $TypeDebug -LogFile $LogFile
                    }
                    if ($CMDriverPackage.Version -eq $HPDriverPack.Version) {
			            CMTraceLog -Message "... CM Driver Package is up to date: version ""$($HPDriverPack.Version)""" -Type 1 -LogFile $LogFile 
                    } else {
                         CMTraceLog -Message "... Driver Package version mismatch, updating to HP version ""$($HPDriverPack.Version)"", (Softpaq ""$($HPDriverPack.Id)""), O/S version $($OSVER)" -Type 1 -LogFile $LogFile
                    } # else if ($lCMDriverPackage.Version -eq $HPDriverPack.Version)

                } # else if ( $HPDriverPack )

                ################################################################################################
			    # Now, let's work on the Driver Package STEP in the Driver Module TS

                #CMTraceLog -Message "... Updating CM Task Sequence step with DriverPack Package - lCMDriverPackage.name=$($CMDriverPackage.name)" -Type 1 -LogFile $LogFile    
			    $CMPackageStepFound = Update_TSPackageStep $TSDriverModule $CMDriverPackage $lEntryProdCode $false

			    CMTraceLog -Message "... $($CMPackageStepFound): ""$($CMDriverPackage.Name)""->$($CMDriverPackage.PackageID)" -Type $TypeDebug -LogFile $LogFile  

                <#
                    Set_HPDriverPackage requires the following:
                        Driver Package
                        DriverPack Name/ID (e.g. sp99111)
                        DriverPack Version # (.e.g. 8.0, 10.0, etc.)
                        DriverPack extracted Path on CM Share
                #>
                $CMDriverPackage = Set_HPDriverPackage $CMDriverPackage $HPDriverPack.ID $HPDriverPack.Version $Script:ExtractPackageShareDirCurrent
                Set-Location -Path "C:"

            } else {

                # a DriverPack was not found for this model and O/S
                $CMDriverPackage = $null
                $CMPackageStepFound = $false

            } # else if ( $HPDriverPack )
            <#
                ListView_FillInItem parameters:
                    $pModelsList - list of entries to look at
                    $pRow - which row from the list to work on
                    $pHPDriverpack - the HP DriverPack
                    $pTSStepFound - tells if TS step exists for this package
            #>
            ListView_FillInItem $pModelsList $i $HPDriverPack $CMPackageStepFound    

        } else {
            # item is NOT checked, so clear the fields in the list
            ListView_ClearRow $pModelsList $i
        } # else if ( $i -in $pCheckedItemsList )

    } # for ( $i = 0; $i -lt $pModelsList.RowCount; $i++ )  

    CMTraceLog -Message "*** Done Downloading ***" -Type 1 -LogFile $LogFile

} # Function Option_Download

#=====================================================================================
<#
    Function Move_CMPackage
    Move a CM Package to a OS folder based on Package source information
    example:
        Packages\Driver Packages
            \Windows 10
                \1809
                \1903
                \1909
                etc.
#>
Function Move_CMPackage {
    [CmdletBinding()]
	param($pCMDriverPackage, $pOSVersion)

    CMTraceLog -Message "... >> Move_CMPackage" -Type $TypeDebug -LogFile $LogFile

    # find out if we are working in OS Folders

    $ObjNameSpace = "ROOT\sms\site_$siteCode"
    $PkgTypeName = "SMS_Package" # a Type 2 SCCM Package Object, seems reserved for Folders

    if ( $Script:UseCM_OSFolders ) {
        #---------------------------------------------------------------------------
        # create CM Package Folders based on OS versions - used to move packages to
        Manage_CM_Folders

        #---------------------------------------------------------------------------
        # create CM Package Folders based on OS versions - used to move packages to
    
        CMTraceLog -Message "$($pOSVersion) - $($pCMDriverPackage.Name) - $($pCMDriverPackage.PackageID) - $($pCMDriverPackage.PkgSourcePath)" -Type $TypdeDebug -LogFile $LogFile
        
        $DriverPkgName = "Driver Packages"
        $folder = Get-WmiObject -Namespace $ObjNameSpace -Class SMS_ObjectContainerNode -Filter "ObjectTypeName = '$PkgTypeName'" | `
            ? { $_.Name -eq $DriverPkgName }   # is this folder a subfolder of 'Driver Packages'?
        #write-host "Folder: $($folder.Name) - ContainerNodeID=$($folder.ContainerNodeID)"

        $DriverPkgNameSub = "Windows 10"
        $folder = Get-WmiObject -Namespace $ObjNameSpace -Class SMS_ObjectContainerNode -Filter "ObjectTypeName = '$PkgTypeName'" | `
            ? { ($_.Name -eq $DriverPkgNameSub) -and ($_.ParentContainerNodeID -eq $folder.ContainerNodeID) }   # is this folder a subfolder of 'Driver Packages'?
        #write-host "Folder: $($folder.Name) - ContainerNodeID=$($folder.ContainerNodeID) - ParentNodeID=$($folder.ParentContainerNodeID)"

        $ParentNodeID = $folder.ContainerNodeID            # this is the parent of the OS Version named folders
        Foreach ($OS in $OSVALID) {
            $folder = Get-WmiObject -Namespace "ROOT\sms\site_$siteCode" -Class SMS_ObjectContainerNode -Filter "ObjectTypeName = '$PkgTypeName'" | `
                ? { ($_.Name -eq $OS) -and ($_.ParentContainerNodeID -eq $ParentNodeID) }   # is this folder a subfolder of 'Windows 10'?
            if ( $OS -eq $pOSVersion ) {
                #write-host "Folder: $($folder.Name) - ContainerNodeID=$($folder.ContainerNodeID) - ParentNodeID=$($folder.ParentContainerNodeID)"
                $destfolder = "$($sitecode):\Package\$($DriverPkgName)\$($DriverPkgNameSub)\$($OS)"
                Set-Location -Path "$($SiteCode):" | Out-Null
                Move-CMObject -ObjectId $pCMDriverPackage.PackageID -FolderPath "$destfolder"
                Set-Location -Path "C:\" | Out-Null
                CMTraceLog -Message "... Moved $($pCMDriverPackage.PackageID) to $($destfolder)" -Type $TypeSuccess -LogFile $LogFile
            } # if ( $OS -eq $pOSVersion )
        } # Foreach ($OS in $OSVALID)

    } else {
        #---------------------------------------------------------------------------
        # Move packages to Packages Root folder

        #$folder = Get-WmiObject -Namespace $ObjNameSpace -Class SMS_ObjectContainerNode -Filter "ObjectTypeName = '$PkgTypeName'" 
        $destfolder = "$($sitecode):\Package"
        Set-Location -Path "$($SiteCode):" | Out-Null
        Move-CMObject -ObjectId $pCMDriverPackage.PackageID -FolderPath "$destfolder"
        Set-Location -Path "C:\" | Out-Null
        CMTraceLog -Message "Moved $($pCMDriverPackage.PackageID) to $($destfolder)" -Type $TypeSuccess -LogFile $LogFile
    }

    CMTraceLog -Message "... << Move_CMPackage" -Type $TypeDebug -LogFile $LogFile
    
} # Move_CMPackage

#=====================================================================================
<#
    Function Manage_CM_Folders
    If the user wants, let's create a set of folders to hold Driver Packages by OS Version
    example:
        Packages\Driver Packages
            \Windows 10
                \1809
                \1903
                \1909
                etc.
#>
Function Manage_CM_Folders {

    CMTraceLog -Message "Manage_CM_Folders!" -Type $TypeDebug -LogFile $LogFile
    Set-Location -Path "$($SiteCode):" | Out-Null

    $ObjNameSpace = "ROOT\sms\site_$siteCode"
    $PkgTypeName = "SMS_Package" # a Type 2 SCCM Package Object, seems reserved for Folders

    #---------------------------------------------------------
    # Create 'Driver Packages' folder if it does not exist
    $DriverPkgName = "Driver Packages"

    $folder = Get-WmiObject -Namespace $ObjNameSpace -Class SMS_ObjectContainerNode -Filter "ObjectTypeName = '$PkgTypeName'" | `
        ? { $_.Name -eq $DriverPkgName }
    if ( !$folder ) {
        CMTraceLog -Message "Creating Driver Package folder: $($DriverPkgName)" -Type 1 -LogFile $LogFile
        $folder = ([wmiclass]($ObjNameSpace + ":SMS_ObjectContainerNode")).CreateInstance()
        if ($folder) {
		    $folder.Name = $DriverPkgName
            $folder.ObjectType = "2"		    
		    $folder.ParentContainerNodeID = '0'                        # 'Driver Packages' this is the parent of the next sub-folders
		    $folder.Put() | Out-Null
	    } else {
            CMTraceLog -Message "There was an error creating the folder: $($folder.Name)" -Type 1 -LogFile $LogFile
	    } # if ($FolderInstance)                 
    } # if ( !$folder )

    $folder = Get-WmiObject -Namespace $ObjNameSpace -Class SMS_ObjectContainerNode -Filter "ObjectTypeName = '$PkgTypeName'" | `
        ? { $_.Name -eq $DriverPkgName }
    CMTraceLog -Message "$($folder.Name) - ContainerNodeID=$($folder.ContainerNodeID)" -Type $TypeDebug -LogFile $LogFile

    $ParentNodeID = $folder.ContainerNodeID                           # Container ID of 'Driver Packages' folder, becomes parentID of next folder

    #---------------------------------------------------------
    # Create 'Windows 10' folder if it does not exist

    $DriverPkgName = "Windows 10"

    $folder = Get-WmiObject -Namespace $ObjNameSpace -Class SMS_ObjectContainerNode -Filter "ObjectTypeName = '$PkgTypeName'" | `
        ? { ($_.Name -eq $DriverPkgName) -and ($_.ParentContainerNodeID -eq $ParentNodeID) }   # is this folder a subfolder of 'Driver Packages'?
    if ( !$folder ) {
        CMTraceLog -Message "Creating Driver Package folder: $($DriverPkgName) - ParentNodeID=$($ParentNodeID)" -Type 1 -LogFile $LogFile
        $folder = ([wmiclass]($ObjNameSpace + ":SMS_ObjectContainerNode")).CreateInstance()
        if ($folder) {
		    $folder.Name = $DriverPkgName
            $folder.ObjectType = "2"		    
		    $folder.ParentContainerNodeID = $ParentNodeID
		    $folder.Put() | Out-Null
	    } else {
            CMTraceLog -Message "There was an error creating the folder: $($folder.Name)" -Type 1 -LogFile $LogFile
	    } # if ($FolderInstance)                 
    } # if ( !$folder )

    $folder = Get-WmiObject -Namespace $ObjNameSpace -Class SMS_ObjectContainerNode -Filter "ObjectTypeName = '$PkgTypeName'" | `
        ? { ($_.Name -eq $DriverPkgName) -and ($_.ParentContainerNodeID -eq $ParentNodeID) }   # is this folder a subfolder of 'Driver Packages'?
    CMTraceLog -Message "$($folder.Name) - ContainerNodeID=$($folder.ContainerNodeID) - ParentNodeID=$($folder.ParentContainerNodeID)" -Type $TypeDebug -LogFile $LogFile

    $ParentNodeID = $folder.ContainerNodeID                          # Container ID of 'Windows 10' folder

    #---------------------------------------------------------
    # Create 'OS Version folders' folder if they do not exist

    Foreach ($DriverPkgName in $OSVALID) {

        $folder = Get-WmiObject -Namespace "ROOT\sms\site_$siteCode" -Class SMS_ObjectContainerNode -Filter "ObjectTypeName = '$PkgTypeName'" | `
            ? { ($_.Name -eq $DriverPkgName) -and ($_.ParentContainerNodeID -eq $ParentNodeID) }   # is this folder a subfolder of 'Windows 10'?
        if ( !$folder ) {
            CMTraceLog -Message "Creating Driver Package folder: $($DriverPkgName) - ParentNodeID=$($ParentNodeID)" -Type 1 -LogFile $LogFile
            $folder = ([wmiclass]("\\$FileServerName\ROOT\sms\site_" + $siteCode + ":SMS_ObjectContainerNode")).CreateInstance()
            if ($folder) {
		        $folder.Name = $DriverPkgName
                $folder.ObjectType = "2"		    
		        $folder.ParentContainerNodeID = $ParentNodeID	        
                $folder.Put() | Out-Null
	        } else {
                CMTraceLog -Message "There was an error creating the folder: $($folder.Name)" -Type 1 -LogFile $LogFile
	        } # if ($FolderInstance)                 
        } # if ( !$folder )

        $folder = Get-WmiObject -Namespace "ROOT\sms\site_$siteCode" -Class SMS_ObjectContainerNode -Filter "ObjectTypeName = '$PkgTypeName'" | `
            ? { ($_.Name -eq $DriverPkgName) -and ($_.ParentContainerNodeID -eq $ParentNodeID) }   # is this folder a subfolder of 'Windows 10'?
        CMTraceLog -Message "$($folder.Name) - ContainerNodeID=$($folder.ContainerNodeID) - ParentNodeID=$($folder.ParentContainerNodeID)" -Type $TypeDebug -LogFile $LogFile

    } # Foreach ($DriverPkgName in $OSVALID)

    Set-Location -Path "C:" | Out-Null
    CMTraceLog -Message "Done - Manage_CM_Folders!" -Type $TypeDebug -LogFile $LogFile

} # Function Manage_CM_Modules

$HelpMessage = `
"Report:`
Downloadin multiple lines:`
Setup TS:"


#=====================================================================================
<#
    Function CreateForm
    This is the MAIN function with a Gui that sets things up for the user
#>
Function CreateForm {
    
    Add-Type -assembly System.Windows.Forms

    $LeftOffset = 20
    $TopOffset = 20
    $FieldHeight = 20
    $FormWidth = 800
    $FormHeight = 600

    $CM_form = New-Object System.Windows.Forms.Form
    $CM_form.Text = "CM_Driverpack_Downloader v$($ScriptVersion)"
    $CM_form.Width = $FormWidth
    $CM_form.height = $FormHeight
    $CM_form.Autosize = $true
    $CM_form.StartPosition = 'CenterScreen'

    #----------------------------------------------------------------------------------
    #define a tooltip object
    $tooltips = New-Object System.Windows.Forms.ToolTip
    $ShowHelp={
        #display popup help
        #each value is the name of a control on the form.
    
        Switch ($this.name) {
            "Action"             {$tip = "Select: Report, Download, or Setup CM Task Sequences"}
            "OS_Selection"       {$tip = "Allowed Windows 10 Versions in Script"}
            "CM_Install_Path"    {$tip = "System Path for SCCM Installation"}
            "DL_Path"            {$tip = "Where Softpaqs are downloaded - Root path"}
            "Share_Path"         {$tip = "the SCCM share for hosting the DriverPack drivers - Root path"}
            "Remove_Step_label"  {$tip = "IF Checked, will remove Package Step from Task Sequence `nwhen Package source points to different OS Version"}
            "Remove_Step"        {$tip = "IF Checked, will remove Package Step from Task Sequence `nwhen Package source points to different OS Version"}
            "Use_OS_Folders_label" {$tip = "IF Checked, will move Driver Packages to CM folders based on OS version`nExample: Packages\Driver Packages\Windows 10\1909"}
            "Use_OS_Folders"     {$tip = "IF Checked, will move Driver Packages to CM folders based on OS version`nExample: Packages\Driver Packages\Windows 10\1909"}
        } # Switch ($this.name)

        $tooltips.SetToolTip($this,$tip)

    } #end ShowHelp

    #----------------------------------------------------------------------------------
    $ActionComboBox = New-Object System.Windows.Forms.ComboBox
    $ActionComboBox.Width = 150
    $ActionComboBox.Location  = New-Object System.Drawing.Point($LeftOffset, $TopOffset)
    $ActionComboBox.Name  = "Action"
    $ActionComboBox.DropDownStyle = "DropDownList"
    #Foreach ($MenuItem in 'Report', 'Download', 'Setup CM Task Sequences', 'CM_Folders') {
    Foreach ($MenuItem in 'Report', 'Download', 'Setup CM Task Sequences') {
        [void]$ActionComboBox.Items.Add($MenuItem);
    }  
    $ActionComboBox.SelectedIndex = $defaultIndex

    $buttonGo = New-Object System.Windows.Forms.Button
    $buttonGo.Width = 30
    $buttonGo.Text = 'Go'
    $buttonGo.Location = New-Object System.Drawing.Point(($LeftOffset+155),($TopOffset-1))

    $buttonGo.add_click( {
        $Script:OSVER=$OSVERComboBox.Text
        if ( $Script:OSVER -in $Script:OSVALID ) {
            # get a list of all checked entries (row numbers, starting with 0)
            $lCheckedListArray = @()
            for ($i = 0; $i -lt $dataGridView.RowCount; $i++) {
                if ($dataGridView[0,$i].Value) {
                    $lCheckedListArray += $i
                } # if  
            } # for

            if ($Script:CMConnected -eq $true) {
                switch ( $ActionComboBox.SelectedItem ) {
                    'Report' { Option_Report $dataGridView $lCheckedListArray }
                    'Download' { Option_Download $dataGridView $lCheckedListArray }
                    'Setup CM Task Sequences' { CM_ManageTS $false }      # $false = not just ReportOnly... Fix if needed
                    'CM_Folders' { Manage_CM_Folders }
                } # switch ( $ActionComboBox.SelectedItem )
            } else {
                CMTraceLog -Message "NO CM Connection!! Click on [Connect] button to start" -Type 1 -LogFile $LogFile
            } # else if ($Script:CMConnected -eq $true) 

        } else {
            CMTraceLog -Message "Windows 10 OS Version NOT Supported in Script: $($Script:OSVER) - Must be one of: $($Script:OSVALID)" -Type 3 -LogFile $LogFile  
        } # else
    } ) # $buttonGo.add_click
    
    $CM_form.Controls.AddRange(@($buttonGo, $ActionComboBox))

    #----------------------------------------------------------------------------------
    # Create OS and OS Version display fields - info from .ini file

    $OSTextLabel = New-Object System.Windows.Forms.Label
    $OSTextLabel.Text = "Win 10:"
    $OSTextLabel.location = New-Object System.Drawing.Point(($LeftOffset+200),($TopOffset+4))    # (from left, from top)
    $OSTextLabel.Size = New-Object System.Drawing.Size(50,25)                               # (width, height)
    #$OSTextField = New-Object System.Windows.Forms.TextBox
    $OSVERComboBox = New-Object System.Windows.Forms.ComboBox
    $OSVERComboBox.Size = New-Object System.Drawing.Size(60,$FieldHeight)                  # (width, height)
    $OSVERComboBox.Location  = New-Object System.Drawing.Point(($LeftOffset+250), ($TopOffset))
    $OSVERComboBox.DropDownStyle = "DropDownList"
    $OSVERComboBox.Name = "OS_Selection"
    $OSVERComboBox.add_MouseHover($ShowHelp)
    
    Foreach ($MenuItem in $OSVALID) {
        [void]$OSVERComboBox.Items.Add($MenuItem);
    }  
    $OSVERComboBox.SelectedItem = $OSVER 

    $CM_form.Controls.AddRange(@($OSTextLabel,$OSVERComboBox))

    #----------------------------------------------------------------------------------
    # Create 'Remove Step if wrong OS version' - checkmark

    $RemoveStepLabel = New-Object System.Windows.Forms.Label
    $RemoveStepLabel.Text = "Remove Package Step if wrong OS version"
    $RemoveStepLabel.location = New-Object System.Drawing.Point($LeftOffset,($TopOffset+35)) # (from left, from top)
    $RemoveStepLabel.Size = New-Object System.Drawing.Size(135,25)                           # (width, height)
    $RemoveStepLabel.Name = "Remove_Step_label"
    $RemoveStepLabel.add_MouseHover($ShowHelp)
    $RemoveStepCheck = New-Object System.Windows.Forms.CheckBox
    $RemoveStepCheck.UseVisualStyleBackColor = $True
    $RemoveStepCheck.location = New-Object System.Drawing.Point(($LeftOffset+135),($TopOffset+30))   # (from left, from top)
    $RemoveStepCheck.Size = New-Object System.Drawing.Size(40,25)                            # (width, height)
    $RemoveStepCheck.Name = "Remove_Step"
    $RemoveStepCheck.add_MouseHover($ShowHelp)
    $RemoveStepCheck.add_click( {
            $find = "^[\$]RemoveStepsFromTS"                                                 # find the $RemoveStepsFromTS setting in the ini.ps1 file            
            if ( $RemoveStepCheck.checked ) {
                $Script:RemoveStepsFromTS = $true  
                $lResult = [System.Windows.MessageBox]::Show("Remove Package Steps if wrong OS version?","Remove Steps",1)    # 1 = "OKCancel" ; 4 = "YesNo"
                if ( $lResult -eq 'Ok' ) {
                    CMTraceLog -Message "When Download, TS Steps will be removed if Package has the wrong OS version" -Type 1 -LogFile $LogFile
                    # change the ini.ps1 config for this setting -set as the new default
                    $replace = "`$RemoveStepsFromTS = `$$RemoveStepsFromTS"                   # set up the replacing string to either $false or $true from ini file
                    (Get-Content $IniFIleFullPath) | Foreach-Object {if ($_ -match $find) {$replace} else {$_}} | Set-Content $IniFIleFullPath
                } else {
                    $RemoveStepCheck.Checked = $false
                }          
            } else {
                $Script:RemoveStepsFromTS = $false
                $lResult = [System.Windows.MessageBox]::Show("Keep Package Steps if wrong OS version?","Remove Steps",1)    # 1 = "OKCancel" ; 4 = "YesNo"
                if ( $lResult -eq 'Ok' ) {
                    CMTraceLog -Message "When Download, TS Steps will be maintained if Package has the wrong OS version" -Type 1 -LogFile $LogFile
                    # change the ini.ps1 config for this setting -set as the new default
                    $replace = "`$RemoveStepsFromTS = `$$RemoveStepsFromTS"                   # set up the replacing string to either $false or $true from ini file
                    (Get-Content $IniFIleFullPath) | Foreach-Object {if ($_ -match $find) {$replace} else {$_}} | Set-Content $IniFIleFullPath            
                } else {
                    $RemoveStepCheck.Checked = $true
                } 
            } # else if ( $UseFolderCheck.checked )
        }
    ) # $UseFolderCheck.add_click

    $RemoveStepCheck.Checked = $RemoveStepsFromTS

    $CM_form.Controls.AddRange(@($RemoveStepLabel, $RemoveStepCheck))

    #----------------------------------------------------------------------------------
    # Create 'Use OS Version Folders' - checkmark

    $UseFoldersLabel = New-Object System.Windows.Forms.Label
    $UseFoldersLabel.Text = "Use OS Version Folders"
    $UseFoldersLabel.location = New-Object System.Drawing.Point($LeftOffset,($TopOffset+65)) # (from left, from top)
    $UseFoldersLabel.Size = New-Object System.Drawing.Size(135,25)                           # (width, height)
    $UseFoldersLabel.Name = "Use_OS_Folders_label"
    $UseFoldersLabel.add_MouseHover($ShowHelp)
    $UseFolderCheck = New-Object System.Windows.Forms.CheckBox
    $UseFolderCheck.UseVisualStyleBackColor = $True
    $UseFolderCheck.location = New-Object System.Drawing.Point(($LeftOffset+135),($TopOffset+60))   # (from left, from top)
    $UseFolderCheck.Size = New-Object System.Drawing.Size(40,25)                             # (width, height)
    $UseFolderCheck.Name = "Use_OS_Folders"
    $UseFolderCheck.add_MouseHover($ShowHelp)
    $UseFolderCheck.add_click( {
            $find = "^[\$]UseCM_OSFolders"                                                   # find the $UseCM_OSFolders setting in the ini.ps1 file
            if ( $UseFolderCheck.checked ) {
                $Script:UseCM_OSFolders = $true  
                $lResult = [System.Windows.MessageBox]::Show("Move Driver Packages to OS Version folders?","Move Packages",1)    # 1 = "OKCancel" ; 4 = "YesNo"
                if ( $lResult -eq 'Ok' ) {
                    CMTraceLog -Message "When Download, will move Packages to OS FOlders" -Type 1 -LogFile $LogFile
                    # change the ini.ps1 config for this setting -set as the new default
                    $replace = "`$UseCM_OSFolders = `$$UseCM_OSFolders"                              # set up the replacing string to either $false or $true
                    (Get-Content $IniFIleFullPath) | Foreach-Object {if ($_ -match $find) {$replace} else {$_}} | Set-Content $IniFIleFullPath
                } else {
                    $UseFolderCheck.Checked = $false
                }          
            } else {
                $Script:UseCM_OSFolders = $false
                $lResult = [System.Windows.MessageBox]::Show("Move Driver Packages to root folder?","Move Packages",1)    # 1 = "OKCancel" ; 4 = "YesNo"
                if ( $lResult -eq 'Ok' ) {
                    CMTraceLog -Message "When Download, will move Packages to Packages Root Folder" -Type 1 -LogFile $LogFile
                    # change the ini.ps1 config for this setting -set as the new default
                    $replace = "`$UseCM_OSFolders = `$$UseCM_OSFolders"                              # set up the replacing string to either $false or $true
                    (Get-Content $IniFIleFullPath) | Foreach-Object {if ($_ -match $find) {$replace} else {$_}} | Set-Content $IniFIleFullPath            
                } else {
                    $UseFolderCheck.Checked = $true
                } 
            } # else if ( $UseFolderCheck.checked )
        }
    ) # $UseFolderCheck.add_click

    $UseFolderCheck.Checked = $UseCM_OSFolders

    $CM_form.Controls.AddRange(@($UseFoldersLabel, $UseFolderCheck))

    #----------------------------------------------------------------------------------
    # Create 'Debug Output' - checkmark

    $DebugCheckBox = New-Object System.Windows.Forms.CheckBox
    $DebugCheckBox.Text = 'Debug Output'
    $DebugCheckBox.UseVisualStyleBackColor = $True
    $DebugCheckBox.location = New-Object System.Drawing.Point(($LeftOffset+240),($TopOffset+60))   # (from left, from top)
    $DebugCheckBox.add_click( {
            if ( $DebugCheckBox.checked ) {
                $Script:Debug_Output = $true
            } else {
                $Script:Debug_Output = $false
            }
        }
    ) # $DebugCheckBox.add_click

    $CM_form.Controls.AddRange(@($DebugCheckBox))                    # removed CM Connect Button

    #----------------------------------------------------------------------------------
    # Create CM Connection Path Field (editable by default) and Test Connection Button

    $CMTextField = New-Object System.Windows.Forms.TextBox
    $CMTextField.top = 20
    $CMTextField.left = 20
    $CMTextField.Text = $CMInstall                                                          # populate with CM install Path
    $CMTextField.Multiline = $false 
    $CMTextField.Size = New-Object System.Drawing.Size(360,$FieldHeight)                    # (width, height)
    $CMTextField.ReadOnly = $true
    $CMTextField.Name = "CM_Install_Path"
    $CMTextField.add_MouseHover($ShowHelp)
    
    $DLPathLabel = New-Object System.Windows.Forms.Label
    $DLPathLabel.Text = "DL Path:"
    $DLPathLabel.location = New-Object System.Drawing.Point($LeftOffset,($TopOffset+20))    # (from left, from top)
    $DLPathLabel.Size = New-Object System.Drawing.Size(50,20)                               # (width, height)
    $DLPathLabel.TextAlign = "MiddleRight"
    $DLPathTextField = New-Object System.Windows.Forms.TextBox
    $DLPathTextField.Text = $DownloadSoftpaqDir
    $DLPathTextField.Multiline = $false 
    $DLPathTextField.location = New-Object System.Drawing.Point(($LeftOffset+50),($TopOffset+20))   # (from left, from top)
    $DLPathTextField.Size = New-Object System.Drawing.Size(310,$FieldHeight)                # (width, height)
    $DLPathTextField.ReadOnly = $true
    $DLPathTextField.Name = "DL_Path"
    
    $SharePathLabel = New-Object System.Windows.Forms.Label
    $SharePathLabel.Text = "Share:"
    $SharePathLabel.location = New-Object System.Drawing.Point($LeftOffset,($TopOffset+40)) # (from left, from top)
    $SharePathLabel.Size = New-Object System.Drawing.Size(50,20)                            # (width, height)
    $SharePathLabel.TextAlign = "MiddleRight"
    $SharePathTextField = New-Object System.Windows.Forms.TextBox
    $SharePathTextField.Text = $ExtractPackageShareDir+"{OSVER}"
    $SharePathTextField.Multiline = $false 
    $SharePathTextField.location = New-Object System.Drawing.Point(($LeftOffset+50),($TopOffset+40)) # (from left, from top)
    $SharePathTextField.Size = New-Object System.Drawing.Size(310,$FieldHeight)             # (width, height)
    $SharePathTextField.ReadOnly = $true
    $SharePathTextField.Name = "Share_Path"
    
    $CMGroupBox = New-Object System.Windows.Forms.GroupBox
    $CMGroupBox.location = New-Object System.Drawing.Point(($LeftOffset+360),($TopOffset))     # (from left, from top)
    $CMGroupBox.Size = New-Object System.Drawing.Size(390,90)                              # (width, height)
    $CMGroupBox.text = "CM Path ($($IniFile)):"

    $CMGroupBox.Controls.AddRange(@($CMTextLabel, $CMTextField, $DLPathLabel, $DLPathTextField, $SharePathLabel, $SharePathTextField))

    $CM_form.Controls.AddRange(@($CMGroupBox))

    #----------------------------------------------------------------------------------
    # Create Models list Checked Text box
    # The ListView control allows columns to be used as fields in a row
    
    $ListViewWidth = ($FormWidth-80)
    $ListViewHeight = 160
    $dataGridView = New-Object System.Windows.Forms.DataGridView
    $dataGridView.location = New-Object System.Drawing.Point(($LeftOffset-10),($TopOffset))
    $dataGridView.height = $ListViewHeight
    $dataGridView.width = $ListViewWidth
    $dataGridView.ColumnHeadersVisible = $true                   # the column names becomes row 0 in the datagrid view
    $dataGridView.RowHeadersVisible = $false
    $dataGridView.SelectionMode = 'CellSelect'
    $dataGridView.AllowUserToAddRows = $False                    # Prevents the display of empty last row

    $CheckBoxColumn = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
    $CheckBoxColumn.width = 28

    [void]$DataGridView.Columns.Add($CheckBoxColumn) 
    
    $dataGridView.ColumnCount = 9                                # 1st column is checkbox column

    $dataGridView.Columns[1].Name = 'SysId'
    $dataGridView.Columns[1].Width = 40
    $dataGridView.Columns[1].DefaultCellStyle.Alignment = "MiddleCenter"
    $dataGridView.Columns[2].Name = 'Model'
    $dataGridView.Columns[2].Width = 210
    $dataGridView.Columns[3].Name = 'Available'
    $dataGridView.Columns[3].Width = 90
    $dataGridView.Columns[3].DefaultCellStyle.Alignment = "MiddleCenter"
    $dataGridView.Columns[4].Name = 'CM Ver'
    $dataGridView.Columns[4].Width = 50
    $dataGridView.Columns[4].DefaultCellStyle.Alignment = "MiddleCenter"
    $dataGridView.Columns[5].Name = 'CM OS'
    $dataGridView.Columns[5].Width = 50
    $dataGridView.Columns[5].DefaultCellStyle.Alignment = "MiddleCenter"
    $dataGridView.Columns[6].Name = 'CM Package'
    $dataGridView.Columns[6].Width = 80
    $dataGridView.Columns[6].DefaultCellStyle.Alignment = "MiddleCenter"
    $dataGridView.Columns[7].Name = 'Pkg Source'
    $dataGridView.Columns[7].Width = 100
    $dataGridView.Columns[7].DefaultCellStyle.Alignment = "MiddleCenter"
    $dataGridView.Columns[8].Name = 'TS Step'
    $dataGridView.Columns[8].Width = 55
    $dataGridView.Columns[8].DefaultCellStyle.Alignment = "MiddleCenter"

    # fill the listview box with all the HP Models listed in the ini script
    $HPModelsTable | ForEach-Object {
                        # populate 1st 3 columns: checkmark, ProdId, Model Name
                        $row = @( $true, $_.ProdCode, $_.Model)         
                        [void]$dataGridView.Rows.Add($row)
                } # ForEach-Object

    # next 2 lines clear any selection from the initial data view
    $dataGridView.CurrentCell = $dataGridView[1,1]
    $dataGridView.ClearSelection()

    # Add a CheckBox on header (1st col)

    $CheckAll=New-Object System.Windows.Forms.CheckBox
    $CheckAll.AutoSize=$true
    $CheckAll.Left=9
    $CheckAll.Top=6
    $CheckAll.Checked = $true
    $CheckAll_Click={
        $state = $CheckAll.Checked
        for ($i = 0; $i -lt $dataGridView.RowCount; $i++) {
            $dataGridView[0,$i].Value = $state
        }
    } # $CheckAll_Click={

    $CheckAll.add_Click($CheckAll_Click)

    $dataGridView.Controls.AddRange(@($CheckAll))

    $CMModlesGroupBox = New-Object System.Windows.Forms.GroupBox
    $CMModlesGroupBox.location = New-Object System.Drawing.Point($LeftOffset,($TopOffset+90))     # (from left, from top)
    $CMModlesGroupBox.Size = New-Object System.Drawing.Size(($ListViewWidth+20),($ListViewHeight+30))       # (width, height)
    $CMModlesGroupBox.text = "HP Models"

    $CMModlesGroupBox.Controls.AddRange(@($dataGridView))

    $CM_form.Controls.AddRange(@($CMModlesGroupBox))
    
    #----------------------------------------------------------------------------------
    # Create Output Text Box at the bottom of the dialog

    $Script:TextBox = New-Object System.Windows.Forms.RichTextBox
    $TextBox.Name = $Script:FormOutTextBox                                          # named so other functions can output to it
    $TextBox.Multiline = $true
    $TextBox.Autosize = $false
    $TextBox.ScrollBars = "Both"
    $TextBox.WordWrap = $false
    $TextBox.location = New-Object System.Drawing.Point($LeftOffset,($TopOffset+280))            # (from left, from top)
    $TextBox.Size = New-Object System.Drawing.Size(($FormWidth-60),280)             # (width, height)

    $CM_form.Controls.AddRange(@($TextBox))

    #----------------------------------------------------------------------------------
    # Create Done/Exit Button at the bottom of the dialog

    $buttonDone = New-Object System.Windows.Forms.Button
    $buttonDone.Text = 'Done'
    $buttonDone.Location = New-Object System.Drawing.Point(($FormWidth-120),($FormHeight-50))    # (from left, from top)

    $buttonDone.add_click( {
            $CM_form.Close()
        }
    ) # $buttonDone.add_click
     
    $CM_form.Controls.AddRange(@($buttonDone))
    
    #----------------------------------------------------------------------------------
    # Finally, show the dialog on screen
    
    $Script:CMConnected = Test_CMConnection
    if ( !$Script:CMConnected ) {
        CMTraceLog -Message "Please Verify to CM Environment" -Type 1 -LogFile $LogFile
    }

    $CM_form.ShowDialog() | Out-Null

} # Function CreateForm

# --------------------------------------------------------------------------
# Start of Script
# --------------------------------------------------------------------------

#CMTraceLog -Message "Starting Script: $scriptName, version $ScriptVersion" -Type 1 -LogFile $LogFile


# Create the GUI and take over all actions, like Report and Download

CreateForm
<#
#>
